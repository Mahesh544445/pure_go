package pure_gold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PureGoldApplication {

	public static void main(String[] args) {
		SpringApplication.run(PureGoldApplication.class, args);
		System.out.println("Application Started");
	}

}
