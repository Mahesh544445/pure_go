package pure_gold.service;

import org.springframework.stereotype.Service;
import pure_gold.entity.Recipe;

import java.util.List;
import java.util.Optional;

public interface RecipeService {

    //create
    Recipe createRecipe(Recipe recipe);

    //update
    Recipe updateRecipe(Recipe recipe, long id);
    //read
    Optional<Recipe> getRecipeById(long id);

    List<Recipe> getAllRecipe();
    //delete
    void deleteRecipeById(long id);

}
