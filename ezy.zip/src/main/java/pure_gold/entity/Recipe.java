package pure_gold.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Table
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Recipe {
    //recipe, including title, short Description, Rating,
    // diet type,photo, ingredients, Direction of cooking steps, Nutritional value.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long recipeId;
    private String recipe;
    private String inclluding_titele;
    private String short_description;
    private String rating;
    private String diet_type;
    private String photo;
    private  String ingredients;
    private  String direction_of_cooking_steps;

    private String nutritional_value;
}
