package pure_gold.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.payload.PostDto;
import com.example.demo.service.FileService;

import jakarta.servlet.http.HttpServletResponse;
import pure_gold.entity.Recipe;
import pure_gold.service.RecipeService;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/recipe")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;
    
    @Autowired
	private FileService fileService;
    
    @Value("${project.image}")
	private String path;

    //http://localhost:8080/api/recipe/createRecipe
    @PostMapping("/createRecipe")
    public ResponseEntity<Recipe> createRecipe(@RequestBody Recipe recipe){
        Recipe recipe1=recipeService.createRecipe(recipe);
        return new ResponseEntity<>(recipe, HttpStatus.CREATED);
    }

    //http://localhost:8080/api/recipe/updateRecipe/{id}
    @PutMapping("/updateRecipe/{id}")
    public ResponseEntity<Recipe> updateRecipe(@RequestBody Recipe recipe, @PathVariable long id){
        Recipe updateRecipe=recipeService.updateRecipe(recipe, id);
        return new ResponseEntity<>(updateRecipe, HttpStatus.OK);
    }
    //http://localhost:8080/api/recipe/getRecipeById/{id}
    @GetMapping("/getRecipeById/{id}")
    public ResponseEntity<Recipe> getRecipeById(@PathVariable long id){
        Optional<Recipe> recipe=recipeService.getRecipeById(id);
        return recipe.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(()->new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    //http://localhost:8080/api/recipe/getAllRecipe
    @GetMapping("/getAllRecipe")
    public ResponseEntity<List<Recipe>> getAllRecipes(){
        List<Recipe> recipeList=recipeService.getAllRecipe();
        return new ResponseEntity<>(recipeList, HttpStatus.OK);
    }

    //http://localhost:8080/api/recipe/deleteRecipe/{id}
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/deleteRecipe/{id}")
    public ResponseEntity<String> deleteRecipe(@PathVariable long id){
        recipeService.deleteRecipeById(id);
        return new ResponseEntity<>("Recipe deleted successfully", HttpStatus.OK);
    }
    
    @PostMapping("/image/upload/{id}")
	public ResponseEntity<Recipe> uploadPostImage(@RequestParam("image") MultipartFile image,
			@PathVariable long id) throws IOException{
    		Recipe recipe = this.recipeService.getRecipeById(id).orElseThrow();
		
		String fileName=this.fileService.uploadImage(path, image);
		
		recipe.setPhoto(fileName);
		
		Recipe updatedRecipe = this.recipeService.updateRecipe(recipe, id);
		
		return new ResponseEntity<>(updatedRecipe, HttpStatus.OK);
	}
	
	@GetMapping(value="/image/{imageName}", produces = MediaType.IMAGE_JPEG_VALUE)
	public void downloadImage(@PathVariable("imageName") String imageName, HttpServletResponse response) throws IOException {
		InputStream resource = this.fileService.getResource(path, imageName);
		response.setContentType(MediaType.IMAGE_JPEG_VALUE);
	
		StreamUtils.copy(resource, response.getOutputStream());
		
	}
}
